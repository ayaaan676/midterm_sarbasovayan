# Aura Shop

Topic: Online Shop (clothes, gadgets, cosmetics)

## Group members

- Нұрислам
- (add name)
- (add name)

## Short description

Aura Shop is a small multi-page website of an online store. Users can look at clothes, gadgets and cosmetics, compare products in a table and send a contact form.

## Features

- 5 pages: Home, Products, Compare, About, Contact
- Navigation menu on every page
- Product cards and gallery
- Product comparison table
- Contact form
- Responsive layout for tablet and mobile

## Technologies

- HTML5
- CSS3
- Bootstrap 5
- Google Fonts

## Individual contribution

- Нұрислам: (write what you did)
- Member 2: (write what they did)
- Member 3: (write what they did)

## Website link

(add GitHub Pages or Netlify link here)
